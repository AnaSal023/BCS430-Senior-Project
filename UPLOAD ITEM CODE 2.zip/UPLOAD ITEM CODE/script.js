//THIS CODE IS FOR UPLOAD AN ITEM , THE BOX WITH 'CHOOSE AN ITEM'

var fileInput = document.querySelector("file-input");
var fileList = document.querySelector("files-list");
var numOfFiles = document.querySelector("num-of-files");

fileInput.addEventListener("change", () => {
  fileList.innerHTML = "";
  numOfFiles.textContent = `${fileInput.files.length} Files Selected`;

  for (i of fileInput.files) {
    var reader = new FileReader();
    var listItem = document.createElement("li");
    var fileName = i.name;
    var fileSize = (i.size / 1024).toFixed(1);
    listItem.innerHTML = `<p>${fileName}</p><p>${fileSize}KB</p>`;
    if (fileSize >= 1024) {
      fileSize = (fileSize / 1024).toFixed(1);
      listItem.innerHTML = `<p>${fileName}</p><p>${fileSize}MB</p>`;
    }
    fileList.appendChild(listItem);
  }
});